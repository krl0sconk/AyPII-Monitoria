/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package matrices;

import java.util.Scanner;

/**
 *
 * @author krl0s
 */
public class Matrices {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[][] A = new int[20][20];
        int na, ma;
        int[][] B = new int[20][20];
        int nb, mb;
        Scanner leer = new Scanner(System.in);

        System.out.println("Ingrese na");
        na = leer.nextInt();
        System.out.println("Ingrese ma");
        ma = leer.nextInt();

        System.out.println("Ingrese nb");
        nb = leer.nextInt();
        System.out.println("Ingrese mb");
        mb = leer.nextInt();

        Operaciones oper = new Operaciones();

        oper.LeerMatriz(na, ma, A);
        oper.LeerMatriz(nb, mb, B);

        int[][] C = new int[20][20];
        oper.MultiplicarMatriz(na, ma, nb, mb, A, B, C);
        oper.EscMatriz(na, mb, C);

        int[][] D = new int[20][20];
        oper.TranspuestaMatriz(nb, mb, B, D);
        oper.EscMatriz(mb, nb, D);

        if (oper.CompararMatriz(na, mb, mb, nb, C, D)) {
            int[][] E = new int[20][20];
            oper.SumaMatriz(na, mb, na, mb, C, C, E, 1);
            oper.EscMatriz(na, mb, E);
        } else {
            int[][] E = new int[20][20];
            oper.SumaMatriz(na, ma, nb, mb, A, B, E, -1);
            int[][] F = new int[20][20];
            oper.SumaMatriz(na, ma, na, mb, E, C, F, 1);
            oper.EscMatriz(nb, mb, F);
        }

    }

}
