/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package matrices;

import java.util.Scanner;

/**
 *
 * @author krl0s
 */
public class Operaciones {

    Scanner leer = new Scanner(System.in);

    public void LeerMatriz(int n, int m, int[][] M) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                System.out.println("Ingrese el elemento" + i + "," + j);
                M[i][j] = leer.nextInt();
            }
        }
    }

    public void EscMatriz(int n, int m, int[][] M) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                if (j == 1) {
                    System.out.print("| " + M[i][j]);
                } else if (j == m) {
                    System.out.println(M[i][j] + " |");
                } else {
                    System.out.print(" " + M[i][j]);
                }
            }
        }
    }

    public void MultiplicarMatriz(int na, int ma, int nb, int mb, int[][] A, int[][] B, int[][] R) {
        if (ma == nb) {
            System.out.println("Mult...");
            for (int i = 1; i <= na; i++) {
                for (int j = 1; j <= mb; j++) {
                    R[i][j] = 0;
                    for (int k = 1; k < ma; k++) {
                        R[i][j] += A[i][k] * B[k][j];
                    }
                }
            }
        } else {
            System.out.println("No se puede Multiplicar");
        }
    }

    public void TranspuestaMatriz(int n, int m, int[][] M, int[][] R) {
        System.out.println("Trans..");
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                R[i][j] = M[j][i];
            }
        }
    }

    public boolean CompararMatriz(int na, int ma, int nb, int mb, int[][] A, int[][] B) {
        if (na != nb || ma != mb) {
            return false;
        }
        for (int i = 1; i <= na; i++) {
            for (int j = 1; j <= ma; j++) {
                if (A[i][j] != B[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }

    public void SumaMatriz(int na, int ma, int nb, int mb, int[][] A, int[][] B, int[][] R, int op) {
        if (na == nb && ma == mb) {
            for (int i = 1; i <= na; i++) {
                for (int j = 1; j <= ma; j++) {
                    R[i][j] = A[i][j] + (op * B[i][j]);
                }
            }
        } else {
            System.out.println("No se puede Sumar na = "+na+" nb = "+nb);
        }
    }
}
